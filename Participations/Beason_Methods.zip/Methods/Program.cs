﻿using System;
using System.Collections.Generic;

namespace Methods
{
    class Program
    {
        static List<int> values = new List<int>();
        static void Main(string[] args)
        {
            
            Console.WriteLine("Please enter an animal type. >>");
            string animalType = Console.ReadLine();
            string animalSound = Console.ReadKey();

            static string Speak(string animalType);
            {
                
                
                return animalSound;
                
                
            }   


            


        }
    }
}
