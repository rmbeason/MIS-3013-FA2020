﻿using System;

namespace ProcessingACSV2
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"SalesJan2009.csv";

            string[] lines = File.ReadAllLines(filePath);

            string name = 0;
            double transaction_date = 0;
            string payment_type = 0;

            if (payment_type == "Visa")
            {
                if (country == "United States")
                {
                    
                }
            }
            
        }
    }
}
