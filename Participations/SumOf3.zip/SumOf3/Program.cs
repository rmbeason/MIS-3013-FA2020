﻿/*
 * 
 *  @Author: Rachel Beason
 */

using System;

namespace SumOf3
{
    class Program
    {
        const double LUCKY_NUMBER = 7.777;

        static void Main(string[] args)
        {

            string number1input = Console.ReadLine;
            string number2input = Console.ReadLine;
            string number3input = Console.ReadLine;

            Console.WriteLine("Please enter your first number >>");
            number1input = Console.ReadLine();

            Console.WriteLine("Please enter your second number >>");
            number2input = Console.ReadLine();

            Console.WriteLine("Please enter your third number >>");
            number3input = Console.ReadLine();

            Console.WriteLine(number1input + number2input + number3input) as SumOf3;

            SumOf3* LUCKY_NUMBER;


        }
    }
}
