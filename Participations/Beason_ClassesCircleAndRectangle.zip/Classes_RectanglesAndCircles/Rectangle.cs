﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes_RectanglesAndCircles
{
    class Rectangle
    {
        public double Length { get; set; }

        public Rectangle ()
        {
            Length = 0;
        }
    }
}
