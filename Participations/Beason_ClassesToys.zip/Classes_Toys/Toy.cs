﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes_Toys
{
    class Toy
    {
    }
}
